// skeleton load
$(document).ready(function() {
  $('.chart__review .btn').on('click', function(){
    $(this).toggleClass('show');
    $(this).parents('.chart__info').next('.chart__info--adv').slideToggle('fast');
  }); 
});
